import nltk,time,os,re,random
from nltk import sent_tokenize
# 获取目录中的所有以txt结尾的文件名
def Get_name(file_path):# 提取给定文件夹里的全部以.txt为后缀的绝对路径
    t = []# 存储以.txt为后缀的文件名
    names = os.listdir(file_path)
    pattern = '.+.txt$'# .txt Regular Expression
    for name in names:
        file_name = re.findall(pattern,name)
        if len(file_name)!=0:
            name = file_path+'/'+name
            t.append(name)
    return t
# 分句处理
def Sent_Cut(file_names):
    s=[]
    for file_name in file_names:
        with open(file_name,'r',encoding='utf-8') as f:
            data = f.read()
            sents = re.findall(r"(.+)?\.$",data,re.DOTALL)
            try:
                SENTS = sent_tokenize(sents[0])
            except IndexError:
                continue
            else:
                for sent in SENTS:
                    s.append(sent)
    # 得到句子列表                
    return s
# 分词处理
def Words_Cut(file_names):# 文件名列表、是否是全文
    w=[]
    stop_words = nltk.corpus.stopwords.words('english')
    for file_name in file_names:
        with open(file_name,'r',encoding='utf-8') as f:
            data = f.read()
            sents = re.findall(r"(.+)?\.$",data,re.DOTALL)
        # 分词清洗
        for one_sent in sents:
            words = nltk.word_tokenize(one_sent)# 化为元素
            words = [word.lower() for word in words]
            words = [word for word in words if word not in stop_words]
            words = [word.replace('\n','').replace("'s",'').replace("n't",'').replace("(",'').replace(")",'').replace(',','')for word in words]
            words =[word.replace(';','').replace(' ','').replace('.','').replace('=','').replace('“','').replace('”','').replace("%","") for word in words]
            words =[word.replace(":",'').replace('：','').replace('\\','')for word in words if set(word) & set("0123456789'|+_‘’''=-!@#$%^&*（）(),.") == set()]
            words =[word for word in words if word != '']
            for word in words:
                w.append(word)
    # 得到了干净的单词列表
    return w
# 求概率
def Get_Prob(data_w,lsstring):
    prob = 0
    for i in range(len(lsstring)):
        try:
            prob += data_w[lsstring[i]] + data_w[lsstring[i-1]]# 用频率近似句子发生的概率
        except IndexError:
            prob += data_w[lsstring[i]]
        except KeyError:
            prob += 0
    return prob
# 训练模型
def words_model(data_w,data_s):# 模型为2元句法
    sent_prob={}
    #print(count,len(data_s))
    stop_words = nltk.corpus.stopwords.words('english')
    for sent in data_s:
        words = nltk.word_tokenize(sent)
        words = [word for word in words if word not in stop_words]
        words = [word.lower() for word in words]
        words = [word.replace('\n','').replace("'s",'').replace("n't",'').replace("(",'').replace(")",'').replace(',','')for word in words]
        words =[word.replace(';','').replace(' ','').replace('.','').replace('=','').replace('“','').replace('”','').replace("%","") for word in words]
        words =[word.replace(":",'').replace('：','').replace('\\','')for word in words if set(word) & set("0123456789'|+_‘’''=-!@#$%^&*（）(),.") == set()]
        words =[word for word in words if word != '']
        prob = Get_Prob(data_w,words)
        sent_prob[sent] = prob
    return sent_prob

def Get_result(data_w,string,sent_prob):# 得到输出结果
    random.seed(3)
    count = random.randint(0,100)%4
    sent = string# 启动语句
    data = sent_prob
    res=[]# 用列表储存输出语句
    # 对给定的句子，在数据集中找出最大概率，输出最大概率的语句并更新当前句为输出句
    while count>=0:
        n = 0
        for kkey in sent_prob.keys():
            if n == 1:
                break
            else:
                words = nltk.word_tokenize(sent)
                now_prob = Get_Prob(data_w,words)
                max_prob = (now_prob+sent_prob[kkey])/(now_prob*sent_prob[kkey]+1)# 最大概率
                out = kkey
                for key in data.keys():
                    a = (now_prob+data[key])/(now_prob*data[key]+1)
                    if max_prob < a and key not in res:
                        max_prob = a
                        out = key
                n = 1
                res.append(out)
                count = count - 1
                sent = out
    final = ''
    for i in res:# 输出结果
        i.strip('\n')
        final = final + i
    print(final)
# 正式运行
if __name__=="__main__":
    path = ''#数据集地址的绝对路径
    #摘要
    anames = Get_name(path+'/Abstract')
    # 关键词
    knames = Get_name(path+'/Keywords and phrases')
    # 正文
    inames = Get_name(path+'/Introduction')
    # 总结
    cnames = Get_name(path+'/Conclusion')
    # 参考文献
    rnames = Get_name(path+'/References')
    # 分别存放
    data_w={}
    data_s=[]
    Abstract_w = Words_Cut(anames)
    Abstract_s = Sent_Cut(anames)
    Keywords_w = Words_Cut(knames)
    Introduction_w = Words_Cut(inames)
    Introduction_s = Sent_Cut(inames)
    Conclusion_w = Words_Cut(cnames)
    Conclusion_s = Sent_Cut(cnames)
    References_w = Words_Cut(rnames)
    References_s = Sent_Cut(rnames)
    data_s = Abstract_s + Introduction_s + Conclusion_s +References_s
    for word in Abstract_w:
        if word not in data_w:
            data_w[word] = 1
        else:
            data_w[word]+= 1
 
    for word in Keywords_w:
        if word not in data_w:
            data_w[word] = 1
        else:
            data_w[word]+= 1
    for word in Introduction_w:
        if word not in data_w:
            data_w[word] = 1
        else:
            data_w[word]+= 1
    for word in Conclusion_w:
        if word not in data_w:
            data_w[word] = 1
        else:
            data_w[word]+= 1
    for word in References_w:
        if word not in data_w:
            data_w[word] = 1
        else:
            data_w[word]+= 1
    sent_prob = words_model(data_w,data_s)
    print("训练耗时"+str(time.process_time())+"秒")
    test = 'Model for graph.'
    Get_result(data_w,test,sent_prob)