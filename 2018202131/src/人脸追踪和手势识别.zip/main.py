from UTILS import *
from glob import glob
from detect import *
from time import sleep
w,h = 360,240
pid = [0.4,0.4,0]
pError = 0
startCounter = 0  # for no Flight 1   - for flight 0
 
#加载模型
device,half,model,classify,names = Initialize()


myDrone = initializeTello()

#img = telloGetFrame(myDrone,w,h)


while True:
    img = telloGetFrame(myDrone,w,h)
    cv2.imshow('Image',img)
    if cv2.waitKey(1) and 0xFF == ord('q'):
        myDrone.land()
        break
    
    ## Flight
    if startCounter == 0:
        myDrone.takeoff()
        
        sleep(3)
        myDrone.move_up(70)
        #myDrone.up(50)
        startCounter = 1
    
    ## Step 1
    #img = telloGetFrame(myDrone,w,h)
    #print(img)
    ## Step 2
    #img, info = findFace(img)
    Face,Gesture,Object = PoseDect(img,device,half,model,classify,names)
    ## Step 3
    center_pos = [w/2, h/2] # 图片中心
    print(Face)
    #print(Gesture)
    #target_pos = [ (face[0] + face[2])/2, (face[1] + face[3])/2 ] # 人脸中心, 按检测代码应该需要遍历列表找出结果是face的,找到第一个即可
    #S = face[2] * face[3] # 面积
    
#下面计算人脸的中心坐标和面积
    
    if Face != []:
        target_pos = [Face[0],Face[1]]
        S = Face[2]*Face[3]
        #print(Face)
        pError = trackFace(myDrone, center_pos, target_pos, S)
    else:
        pass
    

    if Gesture != []:
        if Gesture[4] == 'Stop':
            
            myDrone.land()
            sleep(2)

        if Gesture[4] == 'Switch':
            
            myDrone.flip_right()
            sleep(2)
    else:
        pass

    
    
    '''
    cv2.imshow('Image',img)
    if cv2.waitKey(1) and 0xFF == ord('q'):
        myDrone.land()
        break
    '''
    
