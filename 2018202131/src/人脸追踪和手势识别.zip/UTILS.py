from djitellopy import Tello
from cv2 import cv2
import numpy as np
import math
#import tellopy
 
std_S = 4000
w_extrem = 50
h_extrem = 50
s_extrem = 1500

 # 初始化Tello
def initializeTello():
    
    myDrone = Tello()
    myDrone.connect()
    myDrone.RESPONSE_TIMEOUT = 5
    # myDrone.for_back_velocity = 0
    # myDrone. left_right_velocity = 0
    # myDrone.up_down_velocity = 0
    # myDrone.yaw_velocity = 0
    # myDrone.speed = 0
    #print(myDrone.get_battery())
    myDrone.streamoff()
    myDrone.streamon()
    return myDrone
 
 # 读入Tello图像
def telloGetFrame(myDrone, w= 360,h=240):
    myFrame = myDrone.get_frame_read()
    myFrame = myFrame.frame
    img = cv2.resize(myFrame,(w,h))
    return img
 
 # 查找人脸
def findFace(img):
    faceCascade = cv2.CascadeClassifier('./face_recognition/haarcascade_frontalface_default.xml')
    imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(imgGray,1.1,6  )
 
    myFaceListC = []
    myFaceListArea = []
 
    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),2)
        cx = x + w//2
        cy = y + h//2
        area = w*h
        myFaceListArea.append(area)
        myFaceListC.append([cx,cy])
 
    if len(myFaceListArea) !=0:
        i = myFaceListArea.index(max(myFaceListArea))
        return img, [myFaceListC[i],myFaceListArea[i]]
    else:
        return img,[[0,0],0]
 
 # 追踪人脸
def trackFace(myDrone, center_pos, target_pos, S):
    move_speed = 25 # 这个放到全局变量
    ## PID
    # error = info[0][0] - w//2
    # speed = pid[0]*error + pid[1]*(error-pError)
    # speed = int(np.clip(speed,-100,100))
    
    '''
    error_w = target_pos[0] - center_pos[0]
    error_h = target_pos[0] - center_pos[0]
    error_s = S - std_S
    '''
    #这里貌似写反了？

    for_back_velocity = 0
    left_right_velocity = 0
    up_down_velocity = 0


    error_w = -(target_pos[0] - center_pos[0])
    error_h = -(target_pos[0] - center_pos[0])
    error_s = (S - std_S)
    
    #print(speed)
    # if info[0][0] !=0:
    #     myDrone.yaw_velocity = speed
    # else:
    #     myDrone.for_back_velocity = 0
    #     myDrone.left_right_velocity = 0
    #     myDrone.up_down_velocity = 0
    #     myDrone.yaw_velocity = 0
    #     error = 0
    if error_w > w_extrem:
        left_right_velocity = -move_speed
        #myDrone.left_right_velocity = -move_speed
    elif error_w < -w_extrem:
        left_right_velocity = move_speed
        #myDrone.left_right_velocity = move_speed
    else:
        left_right_velocity = 0
        #myDrone.left_right_velocity = 0

    print("left_right: %d",left_right_velocity)

    if error_h > h_extrem:
        up_down_velocity = -move_speed
        #myDrone.up_down_velocity = -move_speed
    elif error_h < -h_extrem:
        up_down_velocity = move_speed
        #myDrone.up_down_velocity = move_speed
    else:
        up_down_velocity = 0
        #myDrone.up_down_velocity = 0

    print("up_down: %d",up_down_velocity)

    if error_s > s_extrem:
        for_back_velocity = -move_speed
        #myDrone.for_back_velocity = -move_speed
    elif error_s < -s_extrem:
        for_back_velocity = move_speed
        #myDrone.for_back_velocity = move_speed
    else:
        for_back_velocity = 0
        #myDrone.for_back_velocity = 0
    print("for_back: %d",for_back_velocity)

    if myDrone.send_rc_control:
        myDrone.send_rc_control(left_right_velocity,
                                for_back_velocity,
                                up_down_velocity,
                                0)
    #return error