from numpy import random
import torch
from models.experimental import attempt_load
from utils.datasets import LoadStreams, LoadImages,letterbox
from utils.general import (
    check_img_size, non_max_suppression, apply_classifier, scale_coords,
    xyxy2xywh, strip_optimizer, set_logging)
from utils.torch_utils import select_device, load_classifier, time_synchronized
import os
import shutil
import numpy as np
from utils.datasets import *
from cv2 import cv2


def Initialize():
    # Initialize
    out = r'./inference/output'

    set_logging()
    device = select_device('')
    if os.path.exists(out):
        shutil.rmtree(out)  # delete output folder
    os.makedirs(out)  # make new output folder
    half = device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    model = attempt_load('weights/best.pt', map_location=device)  # load FP32 model
    #imgsz = check_img_size(512, s=model.stride.max())  # check img_size
    imgsz = check_img_size(416, s=model.stride.max())
    if half:
        model.half()  # to FP16

    # Second-stage classifier
    classify = False
    if classify:
        modelc = load_classifier(name='resnet101', n=2)  # initialize
        modelc.load_state_dict(torch.load('weights/resnet101.pt', map_location=device)['model'])  # load weights
        modelc.to(device).eval()

    # Set Dataloader


    # Get names and colors
    names = model.module.names if hasattr(model, 'module') else model.names
    colors = [[random.randint(0, 255) for _ in range(3)] for _ in range(len(names))]
    img = torch.zeros((1, 3, imgsz, imgsz), device=device)  # init img
    _ = model(img.half() if half else img) if device.type != 'cpu' else None  # run once

    return device,half,model,classify,names


def PoseDect(OutImg,DEVICE,HALF,model,classify,names,imgsz = 416):
    device = DEVICE
    half = HALF

    res = []
    im0s = OutImg
    # Padded resize
    img = letterbox(im0s, new_shape=640)[0]
    # Convert
    img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, to 3x416x416
    img = np.ascontiguousarray(img)


    img = torch.from_numpy(img).to(device)
    img = img.half() if half else img.float()  # uint8 to fp16/32
    img /= 255.0  # 0 - 255 to 0.0 - 1.0
    if img.ndimension() == 3:
        img = img.unsqueeze(0)

    # Inference
    t1 = time_synchronized()
    pred = model(img, augment=False)[0]

    # Apply NMS
    pred = non_max_suppression(pred, 0.4, 0.5, classes=None, agnostic=False)
    t2 = time_synchronized()

    # Apply Classifier
    if classify:
        pred = apply_classifier(pred, modelc, img, im0s)

    # Process detections
    for i, det in enumerate(pred):  # detections per image
        gn = torch.tensor(im0s.shape)[[1, 0, 1, 0]]  # normalization gain whwh
        if det is not None and len(det):
            # Rescale boxes from img_size to im0 size
            det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0s.shape).round()

            for *xyxy, conf, cls in reversed(det):
                x, y, w, h = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()
                res.append([names[int(cls)], float(conf), x, y, w, h])        


    #res是[[类别，置信度，x,y,w,h].....],现在要将人脸,手势，障碍物的相关信息抽离出来的抽离出来
    Object = []
    gesture = []
    Face = []
    Faceflag = 0 #只识别第一个人脸
    #注意我们的障碍物，手势，人脸(只用第一个人脸)，都是一个框的信息
    
    #print(res)

    for box in res:
        #print(box)
        label = box[0]
        x1, y1, x2, y2 = box[2:]
        # 映射原图尺寸
        x = int(x1 * OutImg.shape[1])
        y = int(y1 * OutImg.shape[0])
        w = int(x2 * OutImg.shape[1])
        h = int(y2 * OutImg.shape[0])
        #其中x,y是矩形的中心坐标

        #这里的标签可能有些不同，你看看要不要改

        if label == 'Stop' or label == 'Switch':
            gesture.extend([x,y,w,h,label])
        elif label == 'Face' and Faceflag == 0:
            Face.extend([x,y,w,h,label])
            Faceflag = 1
        elif label == 'Obstacle':
            Object.extend([x,y,w,h,label])           

#将他们的x,y,w,h以及标签返回
    #return Face,gesture,Object
    return Face



if __name__ == '__main__':
    '''
    path = r'inference/images/stop(1).jpg'
    s = PoseDect(path=path)
    print("输出类别，置信度，x,y,w,h: ")
    print(s)
    '''
    device,half,model,classify,names = Initialize()
    img = cv2.imread(r'./inference/images/stop(1).jpg')

    s = PoseDect(img,device,half,model,classify,names)
    print(s)
    '''
    import PIL
    import numpy as np
    img = np.array(PIL.Image.open('.images/stop(1).jpg'))
    
    for box in s:
        #print(box)
        #print(img.shape)
        x1, y1, x2, y2 = box[2:]
        # 映射原图尺寸
        x = int(x1 * img.shape[1])
        y = int(y1 * img.shape[0])
        w = int(x2 * img.shape[1])
        h = int(y2 * img.shape[0])
        # 计算出左上角和右下角：原x,y是矩形框的中心点
        a = int(x - w / 2)
        b = int(y - h / 2)
        c = int(x + w / 2)
        d = int(y + h / 2)

        print(x1, y1, x1 + x2, y1 + y2)
        print(x, y, x + w, y + h)
        print(a, b, c, d)
        
        cv2.rectangle(img, (a, b), (c, d), (255, 0, 0), 2)
    cv2.imshow('dst', img)
    cv2.waitKey()
    cv2.destroyAllWindows()
'''
